#!/bin/python3

from telethon import TelegramClient # type: ignore #general
from telethon.tl.functions.channels import JoinChannelRequest # type: ignore #general
import telethon
import os
import colorama
import argparse

app_api_id = '23392958'
app_api_hash = '34e9a94b08d041201bbb553b24c0e91b'
client = telethon.TelegramClient('session', app_api_id, app_api_hash)




lim = int(2000)
async def get_messages(client, channel, limit=lim):
   async for message in client.iter_messages(channel, limit):
      if message.text:
          print(colorama.Fore.RED+message.text)
          print(colorama.Fore.YELLOW+"<-----------------------------------[INFO]------------------------------------>") #size 5,5 W AND H
          print("Процесс Crawling-a завершён!")
          message = message.stringify()
          with open("save_messages.txt", "a") as f:
                f.write(message)

async def join_channel(client, channel_link):
          try:
             await client(JoinChannelRequest(channel_link))
             print(f"{colorama.Fore.CYAN}Присоединился к каналу: {channel_link}")
          except Exception as e:
                 print(f"Не удалось присоединиться к каналу: {e}")






async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", help="channel link")
    argum = parser.parse_args()
    channel_link = argum.c  #@sususjsjjsj
    await client.send_message('me', 'hi')
    await get_messages(client, channel_link)
    await join_channel(client, channel_link)
    await client.send_file('https://t.me/+Il-g9iPaSXJjNmYy','save_messages.txt', caption=f'CH: {channel_link} | {lim}_SMS')
with client:
      client.loop.run_until_complete(main())



os.system('rm save_messages.txt')
