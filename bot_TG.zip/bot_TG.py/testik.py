import telebot
import whois
import colorama
from telethon import TelegramClient # type: ignore #general
from telethon.tl.functions.channels import JoinChannelRequest # type: ignore #general
import telethon
import os
import time


api = 'YOUR_API_KEY_FROM_BOTFATHER'

bot = telebot.TeleBot(api)

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, 'Hi, выбери что хочешь сделать. ')
#    bot.send_message(message.chat.id, '[OK] WhoIs\n[NO] Parsing SMS Channel and Chat: ')
    bot.send_message(message.chat.id, "канал/чат пример @durov:")


@bot.message_handler(content_types=['text'])
def main(message):
    bot.send_message(message.chat.id, 'Введи канал пример @durov ')
    bot.send_message(message.chat.id, 'Result:\n', os.system(f'python3 my_bot_args.py -c {message.text}'))


bot.polling()

#@bot.message_handler(content_types=['text'])
#def main(message):
#    bot.send_message(message.chat.id, "Введи domen/ur")
#    bot.send_message(message.chat.id, f'Result:\n{whois.whois(message.text)}') # Analog PRINT for users
#    print(colorama.Fore.YELLOW+"_" * 176, f'\n{colorama.Fore.RED}LOG:{colorama.Fore.WHITE}{message} ')
##@bot.message_handler(content_types=['text'])
##def main(message):
##    bot.send_message(message.chat.id, 'Введи канал пример @durov ')
##    bot.send_message(message.chat.id, f'Result:\n python3 my_bot_args.py -c {messange.text}')


#def parsing(message):
#    bot.send_message(message.chat.id, 'Hi, выбери что хочешь сделать. ')
#    bot.send_message(message.chat.id, '[1] WhoIs\n[2] Parsing SMS Channel and Chat: ')


#@bot.message_handler(content_types=['text'])
#def main(message):
#    bot.send_message(message.chat.id, 'Введи канал пример @durov ')
#    bot.send_message(message.chat.id, f'Result:\n python3 my_bot_args.py -c {messange.text}')

#      bot.send_message(message.chat.id, f'Result:\n{whois.whois(message.text)}') # Analog PRINT for users
#      print(colorama.Fore.YELLOW+"_" * 176, f'\n{colorama.Fore.RED}LOG:{colorama.Fore.WHITE}{message} ')
#    if message.text == '2':
#       ch = message.text

#bot.polling()
