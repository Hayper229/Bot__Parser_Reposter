import os
from time import sleep

while True:
       sleep(5)
       os.system("python3 testik.py")
